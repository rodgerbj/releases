
ALTER TABLE `#__generic_stblrecs` ADD COLUMN  `params` text NOT NULL AFTER `alias`;