<?php
/**
 * @package     Joomla.Administrator
 * @subpackage  com_generic
 *
 * @copyright   Copyright (C) 2005 - 2020 Open Source Matters, Inc. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */
\defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Layout\LayoutHelper;
// textPrefix below is the first part of the language strings displayed by emptystate icon.
// icon must be identified in \media\system\scss\_icomoon.scss

$displayData = [
	'textPrefix' => 'COM_GENERIC_LEAGUES',
	'formURL' => 'index.php?option=com_generic',
	'helpURL' => 'https://github.com/rodgerbj/generic#readme',
	'icon' => 'icon-exclamation',
];

$user = Factory::getApplication()->getIdentity();

if ($user->authorise('core.create', 'com_generic') || count($user->getAuthorisedCategories('com_generic', 'core.create')) > 0) {
	$displayData['createURL'] = 'index.php?option=com_generic&task=league.add';
}

echo LayoutHelper::render('joomla.content.emptystate', $displayData);
