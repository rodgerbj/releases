<?php

\defined('_JEXEC') or die;

use Joomla\CMS\Language\Text;

echo "<hr>Hier kannst du einen Headertext anzeigen.<hr>";

if ($this->item->params->get('show_leagname')) {
	if ($this->params->get('show_league_leagname_label')) {
		echo Text::_('COM_GENERIC_LEAGNAME') . $this->item->leagname;
	} else {
		echo $this->item->leagname;
	}
}

echo "<hr>Hier kannst du eine Fußzeile anzeigen.<hr>";

echo $this->item->event->afterDisplayTitle;
echo $this->item->event->beforeDisplayContent;
echo $this->item->event->afterDisplayContent;