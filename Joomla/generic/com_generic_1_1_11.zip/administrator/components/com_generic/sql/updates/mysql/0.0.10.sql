
ALTER TABLE `#__generic_stblrecs` ADD COLUMN  `state` tinyint(3) NOT NULL DEFAULT 0 AFTER `alias`;

ALTER TABLE `#__generic_stblrecs` ADD COLUMN  `published` tinyint(1) NOT NULL DEFAULT 0 AFTER `alias`;

ALTER TABLE `#__generic_stblrecs` ADD COLUMN  `publish_up` datetime AFTER `alias`;

ALTER TABLE `#__generic_stblrecs` ADD COLUMN  `publish_down` datetime AFTER `alias`;

ALTER TABLE `#__generic_stblrecs` ADD KEY `idx_state` (`published`);