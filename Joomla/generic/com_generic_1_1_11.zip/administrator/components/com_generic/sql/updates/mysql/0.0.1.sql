ALTER TABLE `#__generic_stblrecs` ADD COLUMN  `access` int(10) unsigned NOT NULL DEFAULT 0 AFTER `alias`;

ALTER TABLE `#__generic_stblrecs` ADD KEY `idx_access` (`access`);