<?php

\defined('_JEXEC') or die;

use Joomla\CMS\Language\Text;

echo "<hr>Headertext with header.<hr>";

if ($this->item->params->get('show_leagname')) {
	if ($this->params->get('show_league_leagname_label')) {
		echo Text::_('COM_GENERIC_LEAGNAME') . $this->item->leagname. '<br>';
	} else {
		echo $this->item->leagname . '<br>';
	}
}


foreach ($this->item->jcfields as $field) : ?>
	<?php echo $field->label . ': ' . $field->value; ?>
	<?php endforeach ?>