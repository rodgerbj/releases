DROP TABLE IF EXISTS `#__generic_stblrecs`;
DROP TABLE IF EXISTS `#__generic_leagues`;
