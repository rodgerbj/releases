<?php

\defined('_JEXEC') or die;

use Joomla\CMS\Language\Text;

echo "<hr>Headertext with header.<hr>";

if ($this->item->params->get('show_stblfield1')) {
	if ($this->params->get('show_stblrec_stblfield1_label')) {
		echo Text::_('COM_GENERIC_STBLFIELD1') . $this->item->stblfield1. '<br>';
	} else {
		echo $this->item->stblfield1 . '<br>';
	}
}


foreach ($this->item->jcfields as $field) : ?>
	<?php echo $field->label . ': ' . $field->value; ?>
	<?php endforeach ?>