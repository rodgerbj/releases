<?php

\defined('_JEXEC') or die;

use Joomla\CMS\Language\Text;

echo "<hr>Hier kannst du einen Headertext anzeigen.<hr>";

if ($this->item->params->get('show_stblfield1')) {
	if ($this->params->get('show_stblrec_stblfield1_label')) {
		echo Text::_('COM_GENERIC_STBLFIELD1') . $this->item->stblfield1;
	} else {
		echo $this->item->stblfield1;
	}
}

echo "<hr>Hier kannst du eine Fußzeile anzeigen.<hr>";

echo $this->item->event->afterDisplayTitle;
echo $this->item->event->beforeDisplayContent;
echo $this->item->event->afterDisplayContent;