<?php

/**
 * @package     Joomla.Administrator
 * @subpackage  com_generic
 *
 * @copyright   Copyright (C) 2005 - 2020 Open Source Matters, Inc. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

namespace GenericNamespace\Component\Generic\Administrator\Service\HTML;

defined('JPATH_BASE') or die;

use Joomla\CMS\Factory;

use Joomla\CMS\Language\Text;
use Joomla\CMS\Uri\Uri;
use Joomla\CMS\Router\Route;
use Joomla\Utilities\ArrayHelper;

/**
 * Stblrec HTML class.
 *
 * @since  1.0.0
 */
class AdministratorService
{
	/**
	 * Show the featured/not-featured icon.
	 *
	 * @return  string	The name of the view from page url.
	 *
	 * @since   1.0.0
	 */
	public function callingView()
	{
		$uri = Uri::getInstance();
		$url = $uri->toString();
		$parts = explode("/", $url);
		//initiate $targ with default view (see DisplayController.php)
		$targ = 'stblrecs';
		foreach ($parts as $part) {
			if (!stristr($part, "view")) {
			} else {
				//get substring of part that begins with the word view
				$targx = stristr($part, "view");
				//the name of the view follows the = sign.
				$targ = substr($targx, (strpos($targx, "=") + 1));
			}
		}
		return $targ;
	}

	/**
	 * Show the featured/not-featured icon.
	 *
	 * @param   integer  $value      The featured value.
	 * @param   integer  $i          Id of the item.
	 * @param   boolean  $canChange  Whether the value can be changed or not.
	 *
	 * @return  string	The anchor tag to toggle featured/unfeatured object.
	 *
	 * @since   1.0.0
	 */
	public function featured($value, $i, $canChange = true)
	{
		// Find the view from which AdministratorService was called
		$ASview = $this->callingView();
		// Array of image, task, title, action
		$states = [
			0 => ['unfeatured', $ASview . '.featured', 'COM_CONTACT_UNFEATURED', 'JGLOBAL_ITEM_FEATURE'],
			1 => ['featured', $ASview . '.unfeatured', 'JFEATURED', 'JGLOBAL_ITEM_UNFEATURE'],
		];
		$state = ArrayHelper::getValue($states, (int) $value, $states[1]);
		$icon = $state[0] === 'featured' ? 'star featured' : 'star';

		if ($canChange) {
			$html = '<a href="#" onclick="return Joomla.listItemTask(\'cb' . $i . '\',\'' . $state[1] . '\')" class="tbody-icon'
				. ($value == 1 ? ' active' : '') . '" aria-labelledby="cb' . $i . '-desc">'
				. '<span class="fas fa-' . $icon . '" aria-hidden="true"></span></a>'
				. '<div role="tooltip" id="cb' . $i . '-desc">' . Text::_($state[3]);
		} else {
			$html = '<a class="tbody-icon disabled' . ($value == 1 ? ' active' : '')
				. '" title="' . Text::_($state[2]) . '"><span class="fas fa-' . $icon . '" aria-hidden="true"></span></a>';
		}

		return $html;
	}
}
