ALTER TABLE `#__generic_stblrecs` ADD COLUMN  `language` char(7) NOT NULL DEFAULT '*' AFTER `alias`;

ALTER TABLE `#__generic_stblrecs` ADD KEY `idx_language` (`language`);