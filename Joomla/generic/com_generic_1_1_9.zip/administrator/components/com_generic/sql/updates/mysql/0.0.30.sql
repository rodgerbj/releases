ALTER TABLE `#__generic_stblrecs` ADD COLUMN  `featured` tinyint(3) unsigned NOT NULL DEFAULT 0 COMMENT 'Set if stblrec is featured.';

ALTER TABLE `#__generic_stblrecs` ADD KEY `idx_featured_catid` (`featured`,`catid`);