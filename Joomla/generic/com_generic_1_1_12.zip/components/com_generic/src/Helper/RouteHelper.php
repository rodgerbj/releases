<?php
/**
 * @package     Joomla.Site
 * @subpackage  com_generic
 *
 * @copyright   Copyright (C) 2005 - 2020 Open Source Matters, Inc. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

namespace GenericNamespace\Component\Generic\Site\Helper;

\defined('_JEXEC') or die;

use Joomla\CMS\Categories\CategoryNode;

/**
 * Generic Component Route Helper
 *
 * @static
 * @package     Joomla.Site
 * @subpackage  com_generic
 * @since       1.0.0
 */
abstract class RouteHelper
{
	/**
	 * Get the URL route for a stblrecs from a stblrec ID, stblrecs category ID and language
	 *
	 * @param   integer  $id        The id of the stblrecs
	 * @param   integer  $catid     The id of the stblrecs's category
	 *
	 * @return  string  The link to the stblrecs
	 *
	 * @since   1.0.0
	 */
	public static function getStblrecsRoute($id, $catid)
	{
		// Create the link
		$link = 'index.php?option=com_generic&view=stblrecs&id=' . $id;

		if ($catid > 1) {
			$link .= '&catid=' . $catid;
		}

		return $link;
	}

	/**
	 * Get the URL route for a stblrec from a stblrec ID, stblrecs category ID and language
	 *
	 * @param   integer  $id        The id of the stblrecs
	 * @param   integer  $catid     The id of the stblrecs's category
	 * @param   mixed    $language  The id of the language being used.
	 *
	 * @return  string  The link to the stblrecs
	 *
	 * @since   1.0.0
	 */
	public static function getStblrecRoute($id, $catid)
	{
		// Create the link
		$link = 'index.php?option=com_generic&view=stblrec&id=' . $id;

		if ($catid > 1) {
			$link .= '&catid=' . $catid;
		}

		return $link;
	}

	/**
	 * Get the URL route for a leagues from a league ID, leagues category ID and language
	 *
	 * @param   integer  $id        The id of the leagues
	 * @param   integer  $catid     The id of the leagues's category
	 *
	 * @return  string  The link to the leagues
	 *
	 * @since   1.0.0
	 */
	public static function getLeaguesRoute($id, $catid)
	{
		// Create the link
		$link = 'index.php?option=com_generic&view=leagues&id=' . $id;

		if ($catid > 1) {
			$link .= '&catid=' . $catid;
		}

		return $link;
	}

	/**
	 * Get the URL route for a league from a league ID, leagues category ID and language
	 *
	 * @param   integer  $id        The id of the leagues
	 * @param   integer  $catid     The id of the leagues's category
	 * @param   mixed    $language  The id of the language being used.
	 *
	 * @return  string  The link to the leagues
	 *
	 * @since   1.0.0
	 */
	public static function getLeagueRoute($id, $catid)
	{
		// Create the link
		$link = 'index.php?option=com_generic&view=league&id=' . $id;

		if ($catid > 1) {
			$link .= '&catid=' . $catid;
		}

		return $link;
	}

	/**
	 * Get the URL route for a stblrecs category from a stblrecs category ID and language
	 *
	 * @param   mixed  $catid     The id of the stblrecs's category either an integer id or an instance of CategoryNode
	 * @param   mixed  $language  The id of the language being used.
	 *
	 * @return  string  The link to the stblrecs
	 *
	 * @since   1.0.0
	 */
	public static function getStblrecCategoryRoute($catid)
	{
		if ($catid instanceof CategoryNode) {
			$id = $catid->id;
		} else {
			$id = (int) $catid;
		}

		if ($id < 1) {
			$link = '';
		} else {
			// Create the link
			$link = 'index.php?option=com_generic&view=stblreccategory&id=' . $id;

		return $link;
		}
	}
	/**
	 * Get the URL route for a stblrecs category from a stblrecs category ID and language
	 *
	 * @param   mixed  $catid     The id of the stblrecs's category either an integer id or an instance of CategoryNode
	 * @param   mixed  $language  The id of the language being used.
	 *
	 * @return  string  The link to the stblrecs
	 *
	 * @since   1.0.0
	 */
	public static function getLeaguecategoryRoute($catid)
	{
		if ($catid instanceof CategoryNode) {
			$id = $catid->id;
		} else {
			$id = (int) $catid;
		}

		if ($id < 1) {
			$link = '';
		} else {
			// Create the link
			$link = 'index.php?option=com_generic&view=leaguecategory&id=' . $id;

		return $link;
		}
	}
}