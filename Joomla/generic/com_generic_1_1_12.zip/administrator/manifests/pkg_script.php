<?php
/**
 * @package     Joomla.Site
 * @subpackage  pkg_generic
 *
 * @copyright   Copyright (C) 2005 - 2019 Astrid Günther, Inc. All rights reserved.
 * @license     GNU General Public License version 2 or later;
 * @link        astrid-guenther.de
 */
\defined('_JEXEC') or die;
/**
 * Installation class to perform additional changes during install/uninstall/update
 *
 * @since  1.0.0
 */
class Pkg_GenericInstallerScript
{
	/**
	 * Extension script constructor.
	 *
	 * @since   1.0.0
	 */
	public function __construct()
	{
		$this->minimumJoomla = '4.0';
		$this->minimumPhp    = JOOMLA_MINIMUM_PHP;
	}
	// This options script should have public function postflight?
}
