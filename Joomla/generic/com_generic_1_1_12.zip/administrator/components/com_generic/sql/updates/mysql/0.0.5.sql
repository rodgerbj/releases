ALTER TABLE `#__generic_stblrecs` ADD COLUMN  `catid` int(11) NOT NULL DEFAULT 0 AFTER `alias`;

ALTER TABLE `#__generic_stblrecs` ADD KEY `idx_catid` (`catid`);