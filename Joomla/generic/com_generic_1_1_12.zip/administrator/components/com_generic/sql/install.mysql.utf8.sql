DROP TABLE IF EXISTS `#__generic_leagues`;
DROP TABLE IF EXISTS `#__generic_stblrecs`;
CREATE TABLE IF NOT EXISTS `#__generic_stblrecs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `alias` varchar(400) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '',
  `stblfield1` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 DEFAULT COLLATE=utf8mb4_unicode_ci;

INSERT INTO `#__generic_stblrecs` (`stblfield1`) VALUES
('Nina'),
('Astrid'),
('Elmar');

ALTER TABLE `#__generic_stblrecs` ADD COLUMN  `access` int(10) unsigned NOT NULL DEFAULT 0 AFTER `alias`;

ALTER TABLE `#__generic_stblrecs` ADD KEY `idx_access` (`access`);

ALTER TABLE `#__generic_stblrecs` ADD COLUMN  `catid` int(11) NOT NULL DEFAULT 0 AFTER `alias`;

ALTER TABLE `#__generic_stblrecs` ADD KEY `idx_catid` (`catid`);

ALTER TABLE `#__generic_stblrecs` ADD COLUMN  `state` tinyint(3) NOT NULL DEFAULT 0 AFTER `alias`;

ALTER TABLE `#__generic_stblrecs` ADD COLUMN  `published` tinyint(1) NOT NULL DEFAULT 0 AFTER `alias`;

ALTER TABLE `#__generic_stblrecs` ADD COLUMN  `publish_up` datetime AFTER `alias`;

ALTER TABLE `#__generic_stblrecs` ADD COLUMN  `publish_down` datetime AFTER `alias`;

ALTER TABLE `#__generic_stblrecs` ADD KEY `idx_state` (`published`);

ALTER TABLE `#__generic_stblrecs` ADD COLUMN  `ordering` int(11) NOT NULL DEFAULT 0 AFTER `alias`;

ALTER TABLE `#__generic_stblrecs` ADD COLUMN  `params` text NOT NULL AFTER `alias`;

ALTER TABLE `#__generic_stblrecs` ADD COLUMN `checked_out` int(10) unsigned NOT NULL DEFAULT 0 AFTER `alias`;

ALTER TABLE `#__generic_stblrecs` ADD COLUMN `checked_out_time` datetime AFTER `alias`;

ALTER TABLE `#__generic_stblrecs` ADD KEY `idx_checkout` (`checked_out`);

ALTER TABLE `#__generic_stblrecs` ADD COLUMN  `featured` tinyint(3) unsigned NOT NULL DEFAULT 0 COMMENT 'Set if stblrec is featured.';

ALTER TABLE `#__generic_stblrecs` ADD KEY `idx_featured_catid` (`featured`,`catid`);

ALTER TABLE `#__generic_stblrecs` ADD COLUMN  `language` char(7) NOT NULL DEFAULT '*' AFTER `alias`;

ALTER TABLE `#__generic_stblrecs` ADD KEY `idx_language` (`language`);

CREATE TABLE IF NOT EXISTS `#__generic_leagues` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `alias` varchar(400) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '',
  `access` int(10) unsigned NOT NULL DEFAULT 0,

  `catid` int(11) NOT NULL DEFAULT 0,
 
  `state` tinyint(3) NOT NULL DEFAULT 0,
  `published` tinyint(1) NOT NULL DEFAULT 0,
  `publish_up` datetime,
  `publish_down` datetime,
  
  `ordering` int(11) NOT NULL DEFAULT 0,
  `params` text NOT NULL,
  `checked_out` int(10) unsigned NOT NULL DEFAULT 0,
  `checked_out_time` datetime,
  `featured` tinyint(3) unsigned NOT NULL DEFAULT 0,
  `language` char(7) NOT NULL DEFAULT '*',
  
  PRIMARY KEY (`id`),
   KEY `idx_language` (`language`),
  
  KEY `idx_access` (`access`),
  KEY `idx_catid` (`catid`),
  KEY `idx_state` (`published`),
  KEY `idx_checkout` (`checked_out`),
  KEY `idx_featured_catid` (`featured`,`catid`),

  `leagname` varchar(255) NOT NULL DEFAULT '' ,
  `year` int(15) NOT NULL DEFAULT '2023',
  `comment` text
 
  
  
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 DEFAULT COLLATE=utf8mb4_unicode_ci;
