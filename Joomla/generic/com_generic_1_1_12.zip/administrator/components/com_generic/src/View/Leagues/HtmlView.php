<?php
/**
 * @package     Joomla.Administrator
 * @subpackage  com_generic
 *
 * @copyright   Copyright (C) 2005 - 2020 Open Source Matters, Inc. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

namespace GenericNamespace\Component\Generic\Administrator\View\Leagues;

\defined('_JEXEC') or die;

use Joomla\CMS\Helper\ContentHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\View\HtmlView as BaseHtmlView;
use Joomla\CMS\Toolbar\Toolbar;
use Joomla\CMS\Toolbar\ToolbarHelper;
use Joomla\CMS\Factory;
use Joomla\CMS\MVC\View\GenericDataException;

/**
 * View class for a list of leagues.
 *
 * @since  1.0.0
 */
class HtmlView extends BaseHtmlView
{
	/**
	 * An array of items
	 *
	 * @var  array
	 */
	protected $items;
	
	/**
	 * The pagination object
	 *
	 * @var  \JPagination
	 */
	protected $pagination;
	
	/**
	 * The model state
	 *
	 * @var  \JObject
	 */
	protected $state;

	/**
	 * Form object for search filters
	 *
	 * @var  \JForm
	 */
	public $filterForm;

	/**
	 * The active search filters
	 *
	 * @var  array
	 */
	public $activeFilters;

	/**
	 * Method to display the view.
	 *
	 * @param   string  $tpl  A template file to load. [optional]
	 *
	 * @return  void
	 *
	 * @since   1.0.0
	 */
	public function display($tpl = null): void
	{
		$this->items = $this->get('Items');

		$this->pagination = $this->get('Pagination');

		$this->filterForm = $this->get('FilterForm');
		$this->activeFilters = $this->get('ActiveFilters');
		$this->state = $this->get('State');

		// Check for errors.
		if (count($errors = $this->get('Errors'))) {
			throw new GenericDataException(implode("\n", $errors), 500);
		}

		// Preprocess the list of items to find ordering divisions.
		// TODO: Complete the ordering stuff with nested sets
		foreach ($this->items as &$item) {
			$item->order_up = true;
			$item->order_dn = true;
		}

		if (!count($this->items) && $this->get('IsEmptyState')) {
			$this->setLayout('emptystate');
		}

		$this->addToolbar();

		parent::display($tpl);
	}

	/**
	 * Add the page title and toolbar.
	 *
	 * @return  void
	 *
	 * @since   1.0.0
	 */
	protected function addToolbar()
	{
		$this->sidebar = \JHtmlSidebar::render();

		$canDo = ContentHelper::getActions('com_generic', 'category', $this->state->get('filter.category_id'));
		$user  = Factory::getUser();

		// Get the toolbar object instance
		$toolbar = Toolbar::getInstance('toolbar');

		ToolbarHelper::title(Text::_('COM_GENERIC_MANAGER_LEAGUES'), 'address league');

		if ($canDo->get('core.create') || count($user->getAuthorisedCategories('com_generic', 'core.create')) > 0) {
			$toolbar->addNew('league.add');
	}
		
	if ($canDo->get('core.edit.state')) {
		$dropdown = $toolbar->dropdownButton('status-group')
			->text('JTOOLBAR_CHANGE_STATUS')
			->toggleSplit(false)
			->icon('fa fa-ellipsis-h')
			->buttonClass('btn btn-action')
			->listCheck(true);
		$childBar = $dropdown->getChildToolbar();
		$childBar->publish('leagues.publish')->listCheck(true);
		$childBar->unpublish('leagues.unpublish')->listCheck(true);
	
		$childBar->standardButton('featured')
			->text('JFEATURE')
			->task('leagues.featured')
			->listCheck(true);
		$childBar->standardButton('unfeatured')
			->text('JUNFEATURE')
			->task('leagues.unfeatured')
			->listCheck(true);

		$childBar->archive('leagues.archive')->listCheck(true);

		if ($user->authorise('core.admin')) {
			$childBar->checkin('leagues.checkin')->listCheck(true);
		}

		if ($this->state->get('filter.published') != -2) {
			$childBar->trash('leagues.trash')->listCheck(true);
		}
		if ($this->state->get('filter.published') == -2 && $canDo->get('core.delete')) {
			$childBar->delete('leagues.delete')
				->text('JTOOLBAR_EMPTY_TRASH')
				->message('JGLOBAL_CONFIRM_DELETE')
				->listCheck(true);
		}

		// Add a batch button
		if ($user->authorise('core.create', 'com_generic')
			&& $user->authorise('core.edit', 'com_generic')
			&& $user->authorise('core.edit.state', 'com_generic')) {
			$childBar->popupButton('batch')
				->text('JTOOLBAR_BATCH')
				->selector('collapseModal')
				->listCheck(true);
		}
	}

		if ($user->authorise('core.admin', 'com_generic') || $user->authorise('core.options', 'com_generic')) {
			$toolbar->preferences('com_generic');
		}
		ToolbarHelper::divider();
		ToolbarHelper::help('', false, 'http://bernierodgers.com');
	}
}
