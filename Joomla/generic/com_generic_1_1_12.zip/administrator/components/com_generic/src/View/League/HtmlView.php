<?php
/**
 * @package     Joomla.Administrator
 * @subpackage  com_generic
 *
 * @copyright   Copyright (C) 2005 - 2019 Open Source Matters, Inc. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

namespace GenericNamespace\Component\Generic\Administrator\View\League;

\defined('_JEXEC') or die;

use Joomla\CMS\Helper\ContentHelper;
use Joomla\CMS\Factory;
use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\View\HtmlView as BaseHtmlView;
use Joomla\CMS\Toolbar\ToolbarHelper;

/**
 * View to edit a league.
 *
 * @since  1.0.0
 */
class HtmlView extends BaseHtmlView
{
	/**
	 * The \JForm object
	 *
	 * @var  \JForm
	 */
	protected $form;

	/**
	 * The active item
	 *
	 * @var  object
	 */
	protected $item;

	/**
	 * Display the view.
	 *
	 * @param   string  $tpl  The name of the template file to parse; automatically searches through the template paths.
	 *
	 * @return  mixed  A string if successful, otherwise an Error object.
	 */
	public function display($tpl = null)
	{
		$this->form  = $this->get('Form');
		$this->item = $this->get('Item');

		$this->addToolbar();

		return parent::display($tpl);
	}

	/**
	 * Add the page title and toolbar.
	 *
	 * @return  void
	 *
	 * @since   1.0.0
	 */
	protected function addToolbar()
	{
		Factory::getApplication()->input->set('hidemainmenu', true);
		$user = Factory::getUser();
		$userId = $user->id;
		$isNew = ($this->item->id == 0);

		ToolbarHelper::title($isNew ? Text::_('COM_GENERIC_MANAGER_LEAGUE_NEW') : Text::_('COM_GENERIC_MANAGER_LEAGUE_EDIT'), 'address league');

		// Since we don't track these assets at the item level, use the category id.
		$canDo = ContentHelper::getActions('com_generic', 'category', $this->item->catid);

		// Build the actions for new and existing records.
		if ($isNew) {
			// For new records, check the create permission.
			if ($isNew && (count($user->getAuthorisedCategories('com_generic.league', 'core.create')) > 0)) {
				ToolbarHelper::apply('league.apply');
				ToolbarHelper::saveGroup(
					[
						['save', 'league.save'],
						['save2new', 'league.save2new']
					],
					'btn-success'
				);
			}

			ToolbarHelper::cancel('league.cancel');
		} else {
			// Since it's an existing record, check the edit permission, or fall back to edit own if the owner.
			$itemEditable = $canDo->get('core.edit') || ($canDo->get('core.edit.own') && $this->item->created_by == $userId);
			$toolbarButtons = [];

			// Can't save the record if it's not editable
			if ($itemEditable) {
				ToolbarHelper::apply('league.apply');
				$toolbarButtons[] = ['save', 'league.save'];

				// We can save this record, but check the create permission to see if we can return to make a new one.
				if ($canDo->get('core.create')) {
					$toolbarButtons[] = ['save2new', 'league.save2new'];
				}
			}

			// If checked out, we can still save
			if ($canDo->get('core.create')) {
				$toolbarButtons[] = ['save2copy', 'league.save2copy'];
			}

			ToolbarHelper::saveGroup(
				$toolbarButtons,
				'btn-success'
			);

			
			ToolbarHelper::cancel('league.cancel', 'JTOOLBAR_CLOSE');
		}
		
		ToolbarHelper::divider();
		ToolbarHelper::inlinehelp();
		ToolbarHelper::help('', false, 'http://bernierodgers.com');
	}
}
